import pathlib
import json
from hbctool.util import *

basepath = pathlib.Path(__file__).parent.absolute()

operand_type = {
    "Reg8": (1, to_uint8, from_uint8),
    "Reg32": (4, to_uint32, from_uint32),
    "UInt8": (1, to_uint8, from_uint8),
    "UInt16": (2, to_uint16, from_uint16),
    "UInt32": (4, to_uint32, from_uint32),
    "Addr8": (1, to_int8, from_int8),
    "Addr32": (4, to_int32, from_int32),
    "Imm32": (4, to_uint32, from_uint32),
    "Double": (8, to_double, from_double)
}

f = open(f"{basepath}/data/opcode.json", "r")
opcode_operand = json.load(f)
opcode_mapper = list(opcode_operand.keys())
opcode_mapper_inv = {v: i for i, v in enumerate(opcode_mapper)}
f.close()

def disassemble(bc):
    i = 0
    insts = []
    while i < len(bc):
        opcode = opcode_mapper[bc[i]]
        i+=1
        inst = (opcode, [])
        operand_ts = opcode_operand[opcode]
        for oper_t in operand_ts:
            is_str = oper_t.endswith(":S")
            is_func = oper_t.endswith(":F")
            clean_t = oper_t[:-2] if (is_str or is_func) else oper_t
            size, conv_to, _ = operand_type[clean_t]
            val = conv_to(bc[i:i+size])
            inst[1].append((clean_t, (is_str or is_func), val))
            i+=size
        insts.append(inst)
    return insts

def assemble(insts):
    bc = []
    for opcode, operands in insts:
        op = opcode_mapper_inv[opcode]
        bc.append(op)
        for oper_t, _, val in operands:
            _, _, conv_from = operand_type[oper_t]
            bc += conv_from(val)
    return bc
