from hbctool.util import *
import json
import pathlib
import copy
import struct

basepath = pathlib.Path(__file__).parent.absolute()

MAGIC = 0x1F1903C103BC1FC6
BYTECODE_ALIGNMENT = 4

INVALID_OFFSET = (1 << 23)
INVALID_LENGTH = (1 << 8) - 1

structure = json.load(open(f"{basepath}/data/structure.json", "r"))

headerS = structure["header"]
functionHeaderS = structure["FuncHeader"]
bigIntTableEntryS = structure["BigIntTableEntry"]
regExpTableEntryS = structure["RegExpTableEntry"]
cjsModuleTableS = structure["CJSModuleTable"]
functionSourceTableS = structure["FunctionSourceTable"]
shapeTableEntryS = structure["ShapeTableEntry"]

def align(f):
    f.pad(BYTECODE_ALIGNMENT)

def parse_small_func_header(f):
    w1 = readuint(f, bits=32)
    offset = w1 & 0x1FFFFFF
    paramCount = (w1 >> 25) & 0x1F
    loopDepth = (w1 >> 30) & 0x3
    
    w2 = readuint(f, bits=32)
    bytecodeSizeInBytes = w2 & 0x3FFF
    functionName = (w2 >> 14) & 0xFF
    numberRegCount = (w2 >> 22) & 0x1F
    nonPtrRegCount = (w2 >> 27) & 0x1F
    
    frameSize = readuint(f, bits=8)
    readCacheSize = readuint(f, bits=8)
    
    b3 = readuint(f, bits=8)
    writeCacheSize = b3 & 0x3F
    numCacheNewObject = (b3 >> 6) & 0x1
    privateNameCacheSize = (b3 >> 7) & 0x1
    
    flags = readuint(f, bits=8)
    
    return {
        "offset": offset,
        "paramCount": paramCount,
        "loopDepth": loopDepth,
        "bytecodeSizeInBytes": bytecodeSizeInBytes,
        "functionName": functionName,
        "numberRegCount": numberRegCount,
        "nonPtrRegCount": nonPtrRegCount,
        "frameSize": frameSize,
        "readCacheSize": readCacheSize,
        "writeCacheSize": writeCacheSize,
        "numCacheNewObject": numCacheNewObject,
        "privateNameCacheSize": privateNameCacheSize,
        "flags": flags
    }

def pack_small_func_header(fh):
    w1 = (fh["offset"] & 0x1FFFFFF) | \
         ((fh["paramCount"] & 0x1F) << 25) | \
         ((fh["loopDepth"] & 0x3) << 30)
    w2 = (fh["bytecodeSizeInBytes"] & 0x3FFF) | \
         ((fh["functionName"] & 0xFF) << 14) | \
         ((fh["numberRegCount"] & 0x1F) << 22) | \
         ((fh["nonPtrRegCount"] & 0x1F) << 27)
    b3 = (fh["writeCacheSize"] & 0x3F) | \
         ((fh["numCacheNewObject"] & 0x1) << 6) | \
         ((fh["privateNameCacheSize"] & 0x1) << 7)
    return list(struct.pack("<IIBBBB", w1, w2, fh["frameSize"], fh["readCacheSize"], b3, fh["flags"]))

def parse(f):
    obj = {}
    header = {key: read(f, headerS[key]) for key in headerS}
    obj["header"] = header
    align(f)
    
    # Segment 1: FunctionHeaders
    functionHeaders = []
    for _ in range(header["functionCount"]):
        fh = parse_small_func_header(f)
        if (fh["flags"] >> 5) & 1: # Overflowed
            fh["small"] = copy.deepcopy(fh)
            saved_pos = f.tell()
            large_offset = (fh["functionName"] << 24 ) | fh["offset"]
            f.seek(large_offset)
            for key in functionHeaderS: fh[key] = read(f, functionHeaderS[key])
            f.seek(saved_pos)
        functionHeaders.append(fh)
    obj["functionHeaders"] = functionHeaders
    align(f)

    # Segment 2: StringKinds
    obj["stringKinds"] = [readuint(f, bits=32) for _ in range(header["stringKindCount"])]
    align(f)

    # Segment 3: IdentifierHashes
    obj["identifierHashes"] = [readuint(f, bits=32) for _ in range(header["identifierCount"])]
    align(f)

    # Segment 4: SmallStringTable
    stringTableEntries = []
    for _ in range(header["stringCount"]):
        val = readuint(f, bits=32)
        stringTableEntries.append({
            "isUTF16": bool(val & 1),
            "offset": (val >> 1) & 0x7FFFFF,
            "length": (val >> 24) & 0xFF
        })
    obj["stringTableEntries"] = stringTableEntries
    align(f)

    # Segment 5: OverflowStringTable
    obj["stringTableOverflowEntries"] = [{"offset": readuint(f, bits=32), "length": readuint(f, bits=32)} for _ in range(header["overflowStringCount"])]
    align(f)

    # Segment 6: StringStorage
    obj["stringStorage"] = read(f, ["uint", 8, header["stringStorageSize"]])
    align(f)

    # Segment 7: LiteralValueBuffer
    obj["literalValueBuffer"] = read(f, ["uint", 8, header["literalValueBufferSize"]])
    align(f)

    # Segment 8: ObjectKeyBuffer
    obj["objKeyBuffer"] = read(f, ["uint", 8, header["objKeyBufferSize"]])
    align(f)

    # Segment 9: ObjectShapeTable
    obj["objShapeTable"] = [{key: read(f, shapeTableEntryS[key]) for key in shapeTableEntryS} for _ in range(header["objShapeTableCount"])]
    align(f)

    # Segment 10: BigIntTable
    obj["bigIntEntries"] = [{key: read(f, bigIntTableEntryS[key]) for key in bigIntTableEntryS} for _ in range(header["bigIntCount"])]
    align(f)

    # Segment 11: BigIntStorage
    obj["bigIntStorage"] = read(f, ["uint", 8, header["bigIntStorageSize"]])
    align(f)

    # Segment 12: RegExpTable
    obj["regExpTable"] = [{key: read(f, regExpTableEntryS[key]) for key in regExpTableEntryS} for _ in range(header["regExpCount"])]
    align(f)    
    
    # Segment 13: RegExpStorage
    obj["regExpStorage"] = read(f, ["uint", 8, header["regExpStorageSize"]])
    align(f)

    # Segment 14: CJSModuleTable
    obj["cjsModuleTable"] = [{key: read(f, cjsModuleTableS[key]) for key in cjsModuleTableS} for _ in range(header["cjsModuleCount"])]
    align(f)

    # Segment 15: FunctionSourceTable
    obj["functionSources"] = [{key: read(f, functionSourceTableS[key]) for key in functionSourceTableS} for _ in range(header["functionSourceCount"])]
    align(f)

    obj["instOffset"] = f.tell()
    obj["inst"] = f.readall()
    return obj

def export(obj, f):
    header = obj["header"]
    for key in headerS: write(f, header[key], headerS[key])
    align(f)
    
    overflowedFunctionHeaders = []
    for fh in obj["functionHeaders"]:
        if "small" in fh:
            f.writeall(pack_small_func_header(fh["small"]))
            overflowedFunctionHeaders.append(fh)
        else: f.writeall(pack_small_func_header(fh))
    align(f)

    for val in obj["stringKinds"]: writeuint(f, val, bits=32)
    align(f)

    for val in obj["identifierHashes"]: writeuint(f, val, bits=32)
    align(f)

    for entry in obj["stringTableEntries"]:
        val = (1 if entry["isUTF16"] else 0) | ((entry["offset"] & 0x7FFFFF) << 1) | ((entry["length"] & 0xFF) << 24)
        writeuint(f, val, bits=32)
    align(f)

    for entry in obj["stringTableOverflowEntries"]:
        writeuint(f, entry["offset"], bits=32)
        writeuint(f, entry["length"], bits=32)
    align(f)

    write(f, obj["stringStorage"], ["uint", 8, header["stringStorageSize"]])
    align(f)

    write(f, obj["literalValueBuffer"], ["uint", 8, header["literalValueBufferSize"]])
    align(f)

    write(f, obj["objKeyBuffer"], ["uint", 8, header["objKeyBufferSize"]])
    align(f)

    for entry in obj["objShapeTable"]:
        for key in shapeTableEntryS: write(f, entry[key], shapeTableEntryS[key])
    align(f)

    for entry in obj["bigIntEntries"]:
        for key in bigIntTableEntryS: write(f, entry[key], bigIntTableEntryS[key])
    align(f)

    write(f, obj["bigIntStorage"], ["uint", 8, header["bigIntStorageSize"]])
    align(f)

    for entry in obj["regExpTable"]:
        for key in regExpTableEntryS: write(f, entry[key], regExpTableEntryS[key])
    align(f)    
    
    write(f, obj["regExpStorage"], ["uint", 8, header["regExpStorageSize"]])
    align(f)

    for entry in obj["cjsModuleTable"]:
        for key in cjsModuleTableS: write(f, entry[key], cjsModuleTableS[key])
    align(f)

    for entry in obj["functionSources"]:
        for key in functionSourceTableS: write(f, entry[key], functionSourceTableS[key])
    align(f)

    f.writeall(obj["inst"])

    for ofh in overflowedFunctionHeaders:
        large_offset = (ofh["small"]["functionName"] << 24 ) | ofh["small"]["offset"]
        f.seek(large_offset)
        for key in functionHeaderS: write(f, ofh[key], functionHeaderS[key])
